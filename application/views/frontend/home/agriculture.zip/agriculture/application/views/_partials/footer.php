<footer>
                        
<div class="footer-line">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <p>Customer Supprt  @ 2017. All Rights Reserved</p>
            </div>
            
        </div>
    </div>
</div>
</footer>