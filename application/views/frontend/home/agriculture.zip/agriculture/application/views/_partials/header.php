<header class="clearfix">
    <div class="navbar navbar-inverse my_nav  navbar-fixed-top yamm">
      <div class="col-xs-121 col-sm-12 col-md-12 col-lg-12">
        <a class="navbar-brand" href="#">
        <h3 style="color:#fff;"><b>Customer Service Support</b></h3>
        </a>
      </div>
     
    </div>
  </header>