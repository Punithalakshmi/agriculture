<?php if(get_current_user_id() === TRUE):?>
<div class="md-overlay"></div> 
<footer id="footer-bar" class="row">
	<p id="footer-copyright" class="col-xs-12">
	Copyright &copy; – <script type="text/javascript">var year = new Date();document.write(year.getFullYear());</script> Agriculture
	</p>
</footer>

<?php endif;?>